AvaliaFILMES 🎬
Um site simples e elegante para navegar, descobrir e avaliar filmes. Este projeto foi criado como um exercício prático para demonstrar habilidades em desenvolvimento web front-end, focando em HTML semântico, CSS moderno e interatividade com JavaScript.
